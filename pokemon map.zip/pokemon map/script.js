var lista = new Array;
var lastId;
var cidadeAntiga;

function Cidade() {
    var city = document.getElementById("city").value;
    if (cidadeAntiga == city) {
        Sorteio();
        return;
    } else {
        cidadeAntiga = city;
    }
    limpar();
$.getJSON(
    "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&units=metric&appid=3851f7808ccef4818fc55a5a49858b79",
    function (clima) {
        var temp = clima.main.temp;
        var weather = clima.weather[0].main;
        document.getElementById("weather").innerHTML = weather;
        document.getElementById("temp").innerHTML = temp + "°C";

        if (weather == "Rain" || weather == "Thunderstorm") {
            ptype = "electric"
        } else if (temp < 5) {
            ptype = "ice";
        } else if (5 <= temp && temp < 10) {
            ptype = "water";
        } else if (12 <= temp && temp < 15) {
            ptype = "grass";
        } else if (15 <= temp && temp < 21) {
            ptype = "ground";
        } else if (23 <= temp && temp < 27) {
            ptype = "bug";
        } else if (27 <= temp && temp <= 33) {
            ptype = "rock";
        } else if (33 < temp) {
            ptype = "fire";
        } else {
            ptype = "normal";
        }

	$.getJSON(
		"https://pokeapi.co/api/v2/type/"+ ptype + "/",
		function(pkm) {
			console.log(pkm);
			pkm.pokemon.forEach(function(pokemon) {
				lista.push({"name": pokemon.pokemon.name,"url": pokemon.pokemon.url,"img":"", "id":0});
			});
			Sorteio();
		});
	}
).fail(function() {
    console.log( "error" );
    document.getElementById("erro").innerHTML = "Cidade não enontrada"
	});
}

function Sorteio() {
	var npkm = lista[Math.floor(Math.random()*lista.length)+1];
	var randomPkm = npkm.name;
	if (npkm.img == ""){
		var urlpkm = npkm.url.split('/');
		var pkmId = urlpkm[6];
		if (pkmId > 898) {
			Sorteio();
			return;
		} var pkmIcon = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-viii/icons/" + pkmId + ".png";
			 npkm.img = pkmIcon;
			 npkm.id = pkmId;
	} else {
		  if (npkm.id == lastId) {
			 Sorteio();
			 return;
      }
    }	

	randomPkm = randomPkm[0].toUpperCase() + randomPkm.substring(1)
  ptype = ptype[0].toUpperCase() + ptype.substring(1)
  document.getElementById("nome").innerHTML = "Nome: " + randomPkm;
  document.getElementById("pkdex").innerHTML = "Número na pokédex: " + npkm.id;
  console.log(randomPkm);
  document.getElementById("erro").innerHTML = ""
  document.getElementById("pkmIcon").src = npkm.img;
  document.getElementById("pkmType").src = "assets/types/" + ptype + ".png";
  lastId = npkm.id;
}

	function limpar(){
		lista =[];
		document.getElementById("nome").innerHTML = "";
  	document.getElementById("tipo").innerHTML = "";
  	document.getElementById("pkdex").innerHTML = "";
  	document.getElementById("pkmIcon").src = "";
  	document.getElementById("weather").innerHTML = "";
		document.getElementById("temp").innerHTML = "";
    document.getElementById("erro").innerHTML = "";
    document.getElementById("pkmType").src = "";
	}